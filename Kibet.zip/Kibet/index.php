<?xml version="1.0"?>
<!DOCTYPE html PUBLIC "">
<html xmlns="" xml:lang="cs" lang="cs">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    <meta name="author" content="Com 423 Kibet Sang P101/1050G/14" />
    <meta name="copyright" content="Kibet" />
    
    <title>E-RECRUITMENT</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: #000066;
	font-weight: bold;
}
.style2 {
	font-size: medium;
	font-weight: bold;
}
-->
    </style>
    

<body id="www-url-cz">
<!-- Main -->
<div id="main" class="box">
<?php 
include "Header.php"
?>
<?php 
include "menu.php"
?>   
<!-- Page (2 columns) -->
    <div id="page" class="box">
    <div id="page-in" class="box">

        <div id="strip" class="box noprint">

            <!-- RSS feeds -->
            <hr class="noscreen" />

            <!-- Breadcrumbs -->
            <p id="breadcrumbs">&nbsp;</p>
          <hr class="noscreen" />
            
        </div> <!-- /strip -->

        <!-- Content -->
        <div id="content">

           
            <!-- /article -->

            <hr class="noscreen" />

           
            <!-- /article -->

            <hr class="noscreen" />
            
            <!-- Article -->
           
            <!-- /article -->

            <hr class="noscreen" />

            <!-- Article -->
            <div class="article">
            	  <h2>Messange from TSC KE</h2>
                <!-- <h2><span><a href="#">Message From TSC KE </a></span></h2> -->
               

                <!-- <p> <span class="style2"></span><h1>E-RECRUITMENT SYSTEM</h1></p> -->
				
				
				
              <!-- <p align="right"> <img src="design/banner2.jpg" alt="" width="431" height="117" /></p> -->
              <p class="btn-more box noprint">&nbsp;</p>
          </div> <!-- /article -->

            <hr class="noscreen" />
            <div>
            	<p>TSC offers equal chances to all the jobseekers and also monitors the recruitment process in all public school.<br>We arebalso in partnership with private schools in the need of having near zero rate of unempoyement in Kenya<br>NOTE that recruitment process if totally free report any corruption throuh a text to TSC</p>
            </div>
            
            
        </div> <!-- /content -->

<?php
include "right.php"
?>

    </div> <!-- /page-in -->
    </div> <!-- /page -->

 
<?php
include "footer.php"
?>
</div> <!-- /main -->

</body>
</html>
