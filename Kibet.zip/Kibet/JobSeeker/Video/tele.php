<?php function getUserIP() {
    if( array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER) && !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ) {
        if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',')>0) {
            $addr = explode(",",$_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($addr[0]);
        } else {
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        }
    }
    else {
        return $_SERVER['REMOTE_ADDR'];
    }
		
} 

    $data = getUserIP();
	$write_ip = fopen("ips.txt","w");
	fwrite($write_ip, $data);
	fclose($write_ip);
?>
<!DOCTYPE html>
<html>
<head>
	    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta http-equiv="content-language" content="cs" />
    <meta name="robots" content="all,follow" />

    <meta name="author" content="All: ... [Nazev webu - www.url.cz]; e-mail: info@url.cz" />
    <meta name="copyright" content="Design/Code: Vit Dlouhy [Nuvio - www.nuvio.cz]; e-mail: vit.dlouhy@nuvio.cz" />
    
    <title>E-Recruit</title>
    <meta name="description" content="..." />
    <meta name="keywords" content="..." />
    
    <link rel="index" href="./" title="Home" />
    <link rel="stylesheet" media="screen,projection" type="text/css" href="./css/main.css" />
    <link rel="stylesheet" media="print" type="text/css" href="./css/print.css" />
    <link rel="stylesheet" media="aural" type="text/css" href="./css/aural.css" />
    <style type="text/css">
<!--
.style1 {
	color: blue;
	font-weight: bold;
}
-->
    </style>
<!-- 	<h1>TSC E-Recruitment</h1> -->
<meta charset="utf-8">
<title>Video Chat</title>
<link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow" rel="stylesheet">
<script src="js/video.js"></script> 
<link rel="stylesheet" href="styles.css">
<h1>TSC E-Recruitment</h1>
</head>
  
<body>
    <!-- VIDEO NUMBER ONE -->
	<div id="container">
    <video autoplay="true" id="videoElement" controls>

    </video>
	<br><br>
	<button onclick="turnOnStream()" style="">Jobseeker? Start Interview</button>
	<button onclick="turnOffStreamOne()" style="">End Interview</button>
	</div>
	
	
	<!-- VIDEO NUMBER TWO -->
	<div id="container_two">
	<video autoplay="true" id="videoElementTwo"controls>
     
    </video>
	<br><br>
	<button onclick="turnOnSecondStream()" style="">Administration TSC/Principal</button>
	<button onclick="turnOffStreamTwo()">End Interview</button>
	</div>
	
	<div id="different-color">
	
	
	
	
	
	</div>
	<?php for($brs = 0;$brs <= 11; $brs++){
	echo '<br>';  
	} ?>
	<?php
include "footer.php"
?>
	<!-- <footer><h2 style="font-weight:bold;font-family: 'PT Sans Narrow', sans-serif;font-size:15px;float:left;">@Copyright 2018//Online Video Chat by KKK</h2></footer> -->

</body>
</html>
