function turnOnSecondStream(){
   var video_two = document.querySelector("#videoElementTwo");
   if(navigator.mediaDevices.getUserMedia) {
       navigator.mediaDevices.getUserMedia({video: true, audio: true})
	   .then(function(stream) {
	       video_two.srcObject = stream;
		   start_microphone(stream);
	   })
	   .catch(function(error) {
	     console.log("ERROR TWO");
	   });
   }
}
function turnOnStream() {
 var video = document.querySelector("#videoElement");
if (navigator.mediaDevices.getUserMedia) {       
    navigator.mediaDevices.getUserMedia({video: true, audio: true})
  .then(function(stream) {
    video.srcObject = stream;
	video.play();
	start_microphone(stream);
  })
  .catch(function(err0r) {
    console.log("ERROR ONE");
  });
}
}

function turnOffStreamOne(stream) {
     var video = document.querySelector("#videoElement");
     video.srcObject = null;
	 stream.stop();
	 mediaRecorder.stop();
}
function turnOffStreamTwo(stream) {
     var video_two = document.querySelector("#videoElementTwo");
     video_two.srcObject = null;
	 stream.stop();
	 mediaRecorder.stop();
}
